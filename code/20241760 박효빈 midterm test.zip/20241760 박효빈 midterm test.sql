CREATE TABLE course
    (  id INT PRIMARY KEY,
	   name VARCHAR(100),
	   teacher_id INT);

CREATE TABLE student 
    ( id INT PRIMARY KEY,
	  first_name VARCHAR(50),
	  last_name VARCHAR(50));

CREATE TABLE student_course
    ( student_id INT,
	  course_id INT);

CREATE TABLE teacher
(
    id INT PRIMARY KEY,
	first_name VARCHAR(50),
	last_name VARCHAR(50));

SELECT stuent LEFT JOIN stuent_course;
SELECT teacher LEFT JOIN course;
SELECT course LEFT JOIN student_course;
	

     
	